The data are downloaded from the UCI machine learning repository.

nips.vocab is the vocabulary, each line is a term, of the format
[id]  [word]    [freq]
where [id] is the word id, and [freq] is the term frequency.

nips.libsvm is the corpus, each line is the bag-of-words representation of a document, of the format
[docid]    [id]:[count] [id]:[count] ...
